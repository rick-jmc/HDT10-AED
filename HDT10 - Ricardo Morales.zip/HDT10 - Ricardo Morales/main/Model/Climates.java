package main.Model;


public enum Climates {
    NORMAL,
    RAIN,
    STORM,
    BLIZZARD
}
